/*
 * adc.c
 *
 *  Created on: Nov 25, 2014
 *      Author: Manuel Alejandro
 */
#include <MK64F12.h>
#include "adc.h"



/*unsigned short	adc_read(unsigned char ch)
 * 	Reads the specified adc channel and returns the 16 bits read value
 * 	
 * 	ch -> Number of the channel in which the reading will be performed
 * 	Returns the -> Result of the conversion performed by the adc
 * 
 * */
unsigned short adc_read(unsigned char ch)
{
	SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;	// ADC 0 clock
	ADC0->CFG1 |= ADC_CFG1_MODE(3); /*16bits ADC*/
	ADC0->SC1[0] |= ADC_SC1_ADCH(12); //AD12
	ADC0->SC1[0] |= ADC_SC1_ADCH(31); 
	
	ADC0->SC1[0] = (ch & ADC_SC1_ADCH_MASK) ;
				//(ADC0->SC1[0] & (ADC_SC1_AIEN_MASK | ADC_SC1_DIFF_MASK));     // Write to SC1A to start conversion
	while(ADC0->SC2 & ADC_SC2_ADACT_MASK){ 	 // Conversion in progress
	int a=123;
	}
	if(ADC0->SC1[0] & ADC_SC1_COCO_MASK)
		{ int a=0;}
	
	while(!(ADC0->SC1[0] & ADC_SC1_COCO_MASK)); // Run until the conversion is complete
	return ADC0->R[0];
}
