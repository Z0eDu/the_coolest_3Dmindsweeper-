/*
     Main program: entry point
*/
#include "MK64F12.h"
#include <fsl_device_registers.h>
#include "adc.h"
#include <stdlib.h>


unsigned long value;
unsigned int counter = 0;
int registers[24];

/*
Enables PortC and PortD clocks and initilizes GPIO digital pins for data, latch, clock, and levels1~4
*/
void initialize(void){
	SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK;				//enable Port C clock
	SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;				//enable Port D Clock adc
	SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;				//enable Port D Clock adc
	SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK;				//enable Port D Clock adc
	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK;
	
  PORTA->PCR[4] = PORT_PCR_MUX(001);
	PTA->PDDR &= ~GPIO_PDDR_PDD(0 << 4);
	PORTA->PCR[4] |= PORT_PCR_IRQC(1001);
	NVIC_EnableIRQ(PORTA_IRQn);
	NVIC_SetPriority(PORTA_IRQn, 0);
	
	PORTC->PCR[4] = (1 << 8);						//Set up D9 as GPIO	//latch
	PORTC->PCR[2] = (1 << 8); 						//Set up D6 as GPIO	//clock
	PORTC->PCR[3] = (1 << 8);						//Set up D7 as GPIO	//data
	
	PORTC->PCR[8] = (1 << 8);						//level 1 PTC8
	PORTC->PCR[1] = (1 << 8);						//level 2 PTC1
	PORTB->PCR[19] = (1 << 8);					//level 3 PTB19
	PORTB->PCR[18] = (1 << 8);					//level 4 PTB19
	
	PORTD->PCR[1] = (1 << 8); 						//Set up D0 as GPIO  //level 1
	PORTD->PCR[3] = (1 << 8); 						//Set up D1 as GPIO  //level 2
	PORTD->PCR[2] = (1 << 8); 						//Set up D3 as GPIO  //level 3
	PORTD->PCR[0] = (1 << 8); 						//Set up D5 as GPIO  //level 4
//	PORTC->PCR[12] = (1 << 8); 						//Set up D0 as GPIO  //level 1

	PTD->PDDR |= (1 << 1); 							//data (PORTD->PCR[1] is now an output
	PTD->PDDR |= (1 << 3);							//data (PORTD->PCR[3] is now an output
	PTD->PDDR |= (1 << 2);							//data (PORTD->PCR[2] is now an output
	PTD->PDDR |= (1 << 0);							//data (PORTD->PCR[0] is now an output
  
	PTC->PDDR |= (1 << 8|1<<1);						//level 1 PTC8
	PTB->PDDR |= (1 << 19|1<<18);					//level 3 PTB19
	
	
	PTD->PDOR |= (1 << 1); 							//data (PORTD->PCR[1] is now an output swtich off
	PTD->PDOR |= (1 << 3);							//data (PORTD->PCR[3] is now an output
	PTD->PDOR |= (1 << 2);							//data (PORTD->PCR[2] is now an output
	PTD->PDOR |= (1 << 0);							//data (PORTD->PCR[0] is now an outputc
	
	PTC->PDOR |= (1 << 1|1<<3); 				//data (PORTD->PCR[1] is now an output swtich off
	PTB->PDOR |= (1 << 2|1<<0);					//data (PORTD->PCR[2] is now an output

	
	PTC->PDDR |=(1<<3|1<<4|1<<2); /*enable*/
	PTC->PDOR |=(1<<3|1<<4|1<<2); /*swtich off*/
}

void frequency(int value){ //value
	unsigned long Counter = DEFAULT_SYSTEM_CLOCK/value;
	do
	{
		Counter--;
	} while (Counter);
}

void Delay1(void) {
	unsigned long Counter = DEFAULT_SYSTEM_CLOCK/10;
	do
	{
		Counter--;
	} while (Counter);
}

void shortDelay(void) {
	unsigned Counter =1000;
	do
	{
		Counter--;
	} while (Counter);
}

//shift in values using latches
void shiftin(void){
 		
	for (int level = 0; level < 4; level++) {
		for (int i=0;i<14;i++){
			PTC->PCOR |= (1 << 8| 1<<1);						//level 1 PTC8
			PTB->PSOR |= (1 << 19|1<<18);					//level 3 PTB19
			PTD->PSOR |= (1 << 1|1<<3|1<<2|1<<0);
			PTC->PSOR|=1<<4; //LOW latch
			PTC->PCOR|=1<<3;//LOW data
			if (i==0){
			PTC->PSOR|=1<<3;} //DATA HIGH
			Delay1();
			PTC->PCOR|=1<<2; //HIGH LOCK shift in value
			PTC->PSOR|=1<<2; //LOW LOCK
			PTC->PCOR|=1<<4; //high latch store value to display

			
		}
		
	}
}

/*
Function that will flash the LEDs as fast based on the value
*/
int i=0;
void flash(int value) { 		
	//lets disable interrupts while running this
	//also need to determine what speed corressponds to what values
		i++;
		int a =rand() % 8 ;
		PTC->PCOR = (1 << 3); //LOW data
		if (a %2==1) {
		PTC->PSOR = (1 << 3); //High data
		}	
			PTC->PCOR = (1 << 2); // HIGH clock
			PTC->PSOR = (1 << 2); // LOW clock
		

		
		PTD->PCOR = (1 << 1|1 << 3|1 << 2|1 << 0);	//PORTD
		PTC->PCOR = (1 << 1|1<<8);	//PORTD->PCR[3]	level2
		PTB->PCOR = (1 << 19|1<<18);	//PORTD->PCR[3]	level2
		

		//digitalWrite(latch, HIGH)
		PTC->PCOR = (1 << 4);	//PORTC->PCR[4] latch
		//digitalWrite(latch, LOW)
		PTC->PSOR = (1 << 4);	//PORTC->PCR[4] latch

		//select which level to light up
		if (i%4 == 0) { 
		PTD->PSOR |= (1 << 1);	
		PTC->PSOR |= (1 << 8);			
		}
		if (i%4 == 1) { 
		PTD->PSOR |= (1 << 3);
		PTC->PSOR |= (1 << 1);		}
		if (i%4 == 2) { 
		PTD->PSOR |= (1 << 2);
		PTB->PSOR |=(1<<19);}
		if (i%4 == 3) { 
		PTD->PSOR |= (1 << 0);
		PTB->PSOR |=(1<<18);}
		frequency(value); 
	}



void PORTA_IRQHandler(void) {
	__disable_irq();
	int f=100;
	while(f){
	
	unsigned long max=0;
	for(int k=0;k<5;k++){
		value=adc_read(12);
	if (value>max){max=value;}
	}
	

	unsigned long avg =max/0x1000; //we should spam this function until it flashes long enough
	
	if(avg<1){
	value=5;}
	else if(avg<2){
	value=10;}
	else if(avg<3){
	value=20;}
	else if(avg<5){
	value=50;}
	else if(avg>5){
	value=200;}
	flash(value);
	flash(value);
	flash(value);
	--f;
	}
	__enable_irq();
	PORTA->ISFR = 1 << 4;
	
}


int main() {
	// onboard SW3 button on PTA4, breadboard button on PTB9
	
	initialize();
	while(1){
	shiftin();}

	while(1){};

	return 0;
}
