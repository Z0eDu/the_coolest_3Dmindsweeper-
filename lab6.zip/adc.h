/*
 * adc.h
 *
 *  Created on: Nov 25, 2014
 *      Author: Manuel Alejandro
 */

#ifndef ADC_H_
#define ADC_H_

#include "MK64F12.h"

/* Prototypes */

unsigned short adc_read(unsigned char ch);

#endif /* ADC_H_ */
